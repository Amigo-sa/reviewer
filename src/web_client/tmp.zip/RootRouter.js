import React, {Component, Fragment} from 'react';
import { Route, Switch, HashRouter, Redirect } from 'react-router-dom';
import { inject, observer } from 'mobx-react';
import DevTools from 'mobx-react-devtools';

import { PrivateRoute } from './_utils/PrivateRoute';

import { Authentication } from './auth/Authentication';
import { Main } from './main';
import { Search } from './search';
import { Interaction } from './interaction';
import { Catalogv2 } from './catalog';
import { WhatCanYouDo } from './whatcanyoudo';
import { Chat } from './chat';
import { NewsList } from './newslist';
import ListView from './list/ListView';
import TestComponent from './components/TestComponent/TestComponent';
import { UsefulLinksAll } from './usefullinks';
import Incidents from './incidents/Incidents'

@inject('auth')
@observer
class RootRouter extends Component {

    interceptorToken;

    constructor(props) {
        super(props);
        this.state = {};
    }

    componentDidCatch(err) {
        /* eslint-disable-next-line no-console */
        console.error('Root component catch', err);
        this.setState({ error: err });
    }

    render() {
        return (
            <HashRouter>
                <Fragment>
                    { process.env.NODE_ENV === 'development' ? <DevTools />: null }
                    <Switch>
                        { this.renderIfError() }
                        <Route exact path="/" render={() => <Redirect push to="/main" />} />
                        <PrivateRoute path='/main' component={Main} />
                        <PrivateRoute path='/search' component={Search} />
                        <PrivateRoute path='/interaction' component={Interaction} />
                        <PrivateRoute path='/incident' component={Incidents}/>
                        {/* <PrivateRoute exact path='/todos' component={Todos} />
                        <PrivateRoute path='/todos/create-todo' component={CreateTodoView} />
                        <PrivateRoute exact path='/todos/:todoId' component={TodoView} /> */}
                        <PrivateRoute path='/catalog' component={Catalogv2} />
                        <PrivateRoute path='/whatcanyoudo' component={WhatCanYouDo} />
                        <PrivateRoute path='/newslist' component={NewsList} />
                        <PrivateRoute path='/usefullink' component={UsefulLinksAll} />
                        <PrivateRoute path='/list' component={ListView} />
                        {/* <PrivateRoute path='/chat' component={Chat} /> */}
                        { process.env.NODE_ENV === 'development' ? <Route path='/test' component={TestComponent} /> : null }
                        <Route path='/auth' component={Authentication} />
                        { this.render404() }
                    </Switch>
                    
                </Fragment>
            </HashRouter>
        );
    }

    render404() {
        let page = window.location.pathname + window.location.hash;
        return  <div>404 страница { page } не найдена!</div>
    }

    renderIfError() {
        let { error } = this.state;
        
        if (!error) return null;

        let { name, message, stack } = error;
        
        return (<div>
            <h1>Ошибка приложения {name}</h1>
            <h2>{message}</h2>
            <pre>{stack}</pre>
            </div>)
    }
}

export default RootRouter;
