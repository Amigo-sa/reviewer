import React, {Component} from 'react';
import {IconButton, Grid, Icon} from '@material-ui/core';
import {withStyles} from '@material-ui/core/styles';

const styles = theme => ({
    closeIcon: {
        color: '#fff',
        width: "36px",
        height: "36px",
        background: "#000",
        transition: "all 0.3s cubic-bezier(0.4, 0, 1, 1)",
        position: 'absolute',

        "&:hover": {
            background: "#d8d8d8",
        }
    },
    sizeCloseIcon: {
        fontSize: "20px !important"
    },
    closeButtonWrapper: {
        position: 'absolute',
        right: 80,
        [theme.breakpoints.down('sm')]: {
          position: 'absolute',
          right: 12,
          top: 12,
        },
    }
});

class CloseIcon extends Component {
    render() {
        const { exitCallback, classes } = this.props;
        return (
          <Grid item md={1} lg={1} className={ classes.closeButtonWrapper }>
            <IconButton className={this.props.classes.closeIcon} onClick={exitCallback}>
                <Icon className={this.props.classes.sizeCloseIcon}>close</Icon>
            </IconButton>
          </Grid>
        );
    }
}

CloseIcon.propTypes = {};

export default withStyles(styles)(CloseIcon);
