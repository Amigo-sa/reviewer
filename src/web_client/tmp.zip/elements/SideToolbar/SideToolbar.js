import React, {Component} from 'react';
import { Toolbar, Grid } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';

import { DrugAvatar } from '../../_components/DrugAvatar';
import LikeIconButton from '../../elements/LikeIconButton/LikeIconButton'


const styles = theme => ({
  toolbar: {
    zIndex: '1',
    display: 'flex',
    padding: 0,
    marginLeft: 10,
    [theme.breakpoints.down('sm')]: {
      marginLeft: 10,
    },
  },
  reversingDirection: {
    [theme.breakpoints.down('sm')]: {
      flexDirection: 'row',
      marginTop: 6,
    },
  }
});

class SideToolbar extends Component {
  render() {
    const { classes } = this.props;

    return (
      <Grid item xs={2} sm={2} md={1} lg={1}>
        <Toolbar className={ classes.toolbar }>
          <Grid container direction='column' alignItems='center' className={ classes.reversingDirection }>
            <Grid item>
              <DrugAvatar/>
            </Grid>
            <Grid item>
              <LikeIconButton />
            </Grid>
          </Grid>
        </Toolbar>
      </Grid>
  );
  }
}

SideToolbar.propTypes = {};

export default withStyles(styles)(SideToolbar);
