import React, {Component} from 'react';
import { Typography } from "@material-ui/core";
import QuestionIcon from "../QuestionIcon/QuestionIcon";
import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
  infoBar: {
    width: '241px',
    fontFamily: '"Trebuchet MS", Helvetica, Arial, sans-serif',
    fontSize: '18px',
    fontWeight: 'bold',
    fontStyle: 'normal',
    fontStretch: 'normal',
    lineHeight: '1.39',
    letterSpacing: 'normal',
    color: '#000000',
    top: '0',
    right: '0',
    [theme.breakpoints.down('md')]: {
      fontSize: '12px',
      width: '100%',
      padding: '0 10px',
      marginBottom: '1.33333rem',
      flexDirection: 'row-reverse',
    },
  },
});


/** @deprecated rename to _components/ConfidentInfoBar */
class InfoBar extends Component {
  render() {
    const { classes } = this.props;
    return (
      <Typography className={classes.infoBar}>
        Не указывайте конфиденциальную информацию.<QuestionIcon/>
      </Typography>
    );
  }
}

InfoBar.propTypes = {};

export default withStyles(styles)(InfoBar);
