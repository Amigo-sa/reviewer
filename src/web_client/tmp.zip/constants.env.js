export const SERVER = process.env.FRIEND_APP_CONTEXT_API || '';
export const CONTEXT = process.env.FRIEND_APP_CONTEXT_ROOT;

if (!SERVER) {
    // eslint-disable-next-line no-console
    console.warn('*** NO SERVER API CONTEXT ***');
}

export const REST_PATH = '/rest/state/json/';
export const AUTHENTICATE = SERVER + REST_PATH + 'auth.rpc/authenticate';
export const GET_CURRENT_USER =
    SERVER + REST_PATH + 'friendservice.rpc/getCurrentUser';
export const FIND_USERS = SERVER + REST_PATH + 'friendservice.rpc/findUsers';
export const GET_ACTIVE_INTERACTIONS =
    SERVER + REST_PATH + 'friendservice.rpc/getActiveInteractions';
export const SEARCH_TEMPLATE =
    SERVER + REST_PATH + 'service.rpc/doSearchMobile';
export const GET_TEMPLATE =
    SERVER + REST_PATH + 'friendservice.rpc/getTemplate';
export const GET_TEMPLATE_WITH_TREE_NODE =
    SERVER + REST_PATH + 'friendservice.rpc/getTemplateWithTreeNode';

/* Todos */
export const GET_TODOS = SERVER + REST_PATH + 'service.rpc/getRequestsV2';
export const GET_TODO_BY_ID = SERVER + REST_PATH + 'service.rpc/getRequestsV2';
export const SAVE_TODO = SERVER + REST_PATH + 'service.rpc/saveRequestV2';
export const DELETE_TODO_DEADLINE =
    SERVER + REST_PATH + 'service.rpc/clearDeadlineRequestV2';
export const GET_TODO_COMMENTS =
    SERVER + REST_PATH + 'service.rpc/getProtocols';
export const ADD_TODO_TO_FAVORITE =
    SERVER + REST_PATH + 'friendservice.rpc/addFavorite';

/* Catalog */
export const GET_CATALOG_ITEMS =
    SERVER + REST_PATH + 'friendservice.rpc/getCatalogElements';
export const GET_USER_TEMPLATES_TREE =
    SERVER + REST_PATH + 'friendservice.rpc/getCurrentUserTemplatesTree';

/* Interactions */
export const ADD_TEMPLATE_TO_FAVORITE =
    SERVER + REST_PATH + 'friendservice.rpc/addFavorites';

/* WhatCanYouDo page */
export const GET_FAVORITES =
    SERVER + REST_PATH + 'friendservice.rpc/getUserFavorites';
export const GET_NEWS =
    SERVER + REST_PATH + 'friendservice.rpc/getPageUserActiveNews';
export const GET_ALPHA_LINKS =
    SERVER + REST_PATH + 'friendservice.rpc/getUserReferences';
export const GET_USER_RECOMENDED_TEMPLATES =
    SERVER + REST_PATH + 'friendservice.rpc/getRecommendedShortTemplates';

/* Notifications */
export const GET_NOTIFICATIONS =
    SERVER + REST_PATH + 'friendservice.rpc/getNotifications';
export const SET_READED_NOTIFICATIONS =
    SERVER + REST_PATH + 'friendservice.rpc/setNotificationOverLooked';
export const SET_READED_NOTIFICATIONS_UNIVERSAL =
    SERVER + REST_PATH + 'friendservice.rpc/updateNotifyFlagRead';

export const CONFIRM_ACTION =
    SERVER + REST_PATH + 'friendservice.rpc/confirmAction';

export const SAVE_APPROVAL =
    SERVER + REST_PATH + 'friendservice.rpc/saveApproval';

/* User Util methods */
export const GET_USER_SETTING = SERVER + REST_PATH + 'auth.rpc/getUserSetting';
export const SET_USER_TIMEZONE =
    SERVER + REST_PATH + 'friendservice.rpc/setTimeZone';
export const LOGOUT = SERVER + REST_PATH + 'auth.rpc/logout';

export const INPUT_DEBOUNCE = 300; // text field debounce in ms;
export const MAX_DML_STRING_LENGTH = 45;

export const executeTaskMap =
    SERVER + REST_PATH + 'friendservice.rpc/executeTaskMap';

export const executeTaskElement =
    SERVER + REST_PATH + 'friendservice.rpc/executeTaskElement';

/* Settings names */
export const LINK_TO_OLD_FRIEND_SETTING_NAME = "EOL_REDIRECT_URL";
