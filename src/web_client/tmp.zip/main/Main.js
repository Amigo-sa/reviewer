import React, {Component, Fragment} from 'react';
import { Redirect } from 'react-router-dom'
import { MainPageLayout } from '../_layouts';
import { Search } from '../components/Search';
import { inject, observer } from 'mobx-react';
import NotificationList from '../components/Notifications/NotificationsList';

@inject('search', 'auth')
@observer
class Main extends Component {
    render() {
        return (
            <Fragment>
                <MainPageLayout mainContent={<NotificationList/>}
                    searchPanel={<Search />}
                />
            </Fragment>
        );
    }
}

Main.propTypes = {};

export default Main;
