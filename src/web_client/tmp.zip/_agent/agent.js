import axios from 'axios';
import {
    AUTHENTICATE,
    GET_CURRENT_USER,
	FIND_USERS,
	LOGOUT
} from '../constants.env';


axios.defaults.headers.post["X-App-Name"] = "None";

export const user = {
    auth: (username, password) => {
        //console.log( AUTHENTICATE);
        return axios({
            method: 'post',
            url: AUTHENTICATE,
            withCredentials: true,
            data: {
                arg0: username,
                arg1: password
            }
        });
    },

    get: () => {
        return axios({
            method: 'post',
            url: GET_CURRENT_USER,
            withCredentials: true,
            data: {}
        });
    },

    findUsers: str => {
        return axios({
            method: 'post',
            url: FIND_USERS,
            withCredentials: true,
            data: {
                arg0: str
            }
        });
    },

    logout: () => {
        return axios({
            method: 'post',
            url: LOGOUT,
            withCredentials: true,
            data: {}
        });
    }
};
