export { default as MainPageLayout } from './MainPageLayout';
export { default as OneColumnLayout } from './OneColumnLayout';
export { default as WideColumnLayout } from './WideColumnLayout';