import React, {Component} from 'react';
import {Grid, Typography} from '@material-ui/core';
import {withRouter} from 'react-router';
import {Link} from 'react-router-dom';
import {inject, observer} from 'mobx-react';

@inject('auth', 'layouts', 'notifications')
@observer
class MainPageLayout extends Component {

    componentWillUnmount() {
        this.props.layouts.clearLayout('mainPageLayout');
    }

    getToolbar = (path, user) => {
        let name = user ? user.firstName : 'User';

        return (
            <div className={'Main__Title'}>
                <Typography variant="headline">Добрый день, {name}!{' '}
                    <Link to="/list" style={{color: '#10c111', fontWeight: "inherit", fontFamily: "inherit"}}>
                        {todosString}
                    </Link>
                </Typography>
            </div>
        )
    };

    render() {
        let {mainContent, searchPanel, auth, layouts} = this.props;

        let footerClasses = layouts.mainPageLayout.fullHeight ? 'App__Footer App__Footer_bottom' : 'App__Footer';
        let bodyClasses = layouts.mainPageLayout.fullHeight ? 'App__JustifyTop Body__Footer_bottom' : 'App__JustifyCenter';

        return (
            <div className={bodyClasses}>
                <Grid container className={'App__Body'}>
                    <Grid item xs>
                        <Grid container className={'Main'} id={'mainPageLayoutContent'}>
                            <Grid item lg={12} className={'Main__Content'}>
                                {this.getToolbar(this.props.location.pathname, auth.user.kadr)}
                                {mainContent}
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
            </div>
        );
    }
}

export default withRouter(MainPageLayout);
