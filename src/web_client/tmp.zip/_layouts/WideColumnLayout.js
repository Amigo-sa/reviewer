import React, { Component } from 'react';
import { withRouter } from 'react-router-dom'
import {
    Grid,
    Icon,
    Typography,
    Button,
    withStyles,
    withWidth
} from '@material-ui/core';

import PropTypes from 'prop-types';

import { DrugAvatar } from '../_components/DrugAvatar';

import LikeIconButton from '../elements/LikeIconButton/LikeIconButton';
import theme from '../theme';

const styles = theme => ({
    left: {
        position: 'absolute',
        top: 4,
        left: 7,
        alignItems: 'center',
        width: 'auto'
    },
    right: {
        position: 'absolute',
        top: 4,
        right: 0,
        alignItems: 'center',
        width: 'auto'
    }
});

@withWidth()
@withStyles(styles)
@withRouter
class WideColumnLayout extends Component {
    state = {
        anchorEl: null,
        value: 'sorting1'
    };

    render() {
        let { classes, width, children, title, subTitle, showLikeButton, likeCallback } = this.props;

        let isXs = width === 'xs' || width === 'sm';

        if (typeof title === 'string') {
            title = <Typography variant={"headline"} className={classes.mainTitle}>{title}</Typography>
        }

        let { menu: Menu } = this.props;

        return (
            <Grid container className={'App__Body'} spacing={0} >
                <Grid item xs>
                    <Grid container className={'Main'} id={'mainPageLayoutContent'}>
                        <Grid item className={['Main__Toolbar', classes.mainToolbar ].join(' ')}>
                            <Grid container spacing={24} className={classes.left} direction={isXs ? "row" : "column"}>
                                <Grid item><DrugAvatar /></Grid>
                                {Menu ? <Grid item><Menu isXs={isXs} /></Grid> : null}
                                { showLikeButton ? <LikeIconButton like={likeCallback}/> : null }
                            </Grid>
                            <div className={classes.right}>
                                {this.renderCloseButton()}
                            </div>
                        </Grid>
                        <Grid item xs>
                            <Grid container className={['Main__Content', classes.mainContent ].join(' ')} direction="column">
                                <Grid item className={'Main__Title'}>
                                    {title}
                                    {subTitle}
                                </Grid>
                                <Grid item>
                                    {children}
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
            </Grid >
        )
    }

    renderCloseButton() {
        let { closeButton, onCloseButtonClick } = this.props;
        if (closeButton === false) return null;
        return <Grid item>
            <Button variant="fab" mini color="secondary"
                onClick={e => onCloseButtonClick ? onCloseButtonClick(e) : this.props.history.goBack()}>
                <Icon className={this.props.classes.sizeCloseIcon}>close</Icon>
            </Button>
        </Grid>
    }
}

WideColumnLayout.propTypes = {
    title: PropTypes.oneOfType([PropTypes.string, PropTypes.element]),
    closeButton: PropTypes.bool,
    //menu: PropTypes.element
};

export default WideColumnLayout;
