import React, { Component } from 'react';
import {
    Grid,
    Typography,
    withStyles,
} from '@material-ui/core';
import SideToolBar from '../elements/SideToolbar/SideToolbar';
import CloseIcon from '../elements/CloseIcon/CloseIcon';
import InfoBar from '../elements/InfoBar/InfoBar';

import { withRouter } from 'react-router-dom';

const style = theme => ({
    Main__Toolbar: {
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%'
    },
    Main__ContentContainer: {
        [theme.breakpoints.down('md')]: {
            width: '100%',
            flexDirection: 'row-reverse',
            display: 'flex'
        },
        [theme.breakpoints.down('sm')]: {
            marginTop: 52,
        }
    }
});

/** @deprecated */
class OneColumnLayout extends Component {
    render() {
        let {
            mainContent,
            children,
            showInfoBar,
            showSideToolbar,
            showCloseIcon,
            exitCallback
        } = this.props;

        return (
            <Grid container direction={'column'} className={'App__Body'}>
                <Grid container className={'Main'}>
                    <Grid item xs>
                        <Grid
                            container
                            lg={12}
                            sm={12}
                            xs={12}
                            md={12}
                            justify={'space-between'}
                            className={'Main__Toolbar'}
                        >
                            <Grid item>
                                {showSideToolbar ? <SideToolBar /> : null}
                            </Grid>
                            <Grid item>
                                {showCloseIcon ? (
                                    <CloseIcon exitCallback={exitCallback || (() => this.props.history.goBack())} />
                                ) : null}
                            </Grid>
                        </Grid>
                    </Grid>
                    <Grid item lg={12} className={'Main__Content'}>
                        <Grid
                            container
                            lg={12}
                            spacing={40}
                            className={'Main__ContentContainer'}
                        >
                            <Grid
                                item
                                className={'Container Container_wrap'}
                                xs={12}
                                md={12}
                                lg={8}
                            >
                                <Grid>
                                    <Grid item>{this.renderHeader()}</Grid>
                                    <Grid item>{mainContent || children}</Grid>
                                </Grid>
                            </Grid>
                            {showInfoBar ? (
                                <Grid item xs={12} md={12} lg={4}><InfoBar /></Grid>
                            ) : null}
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>

        );
    }

    renderHeader() {
        let { title } = this.props;

        if (typeof title === 'string')
            return (
                <Typography variant={'headline'} className={'Main__Title'}>
                    {title}
                </Typography>
            );
        return title;
    }
}

OneColumnLayout.defaultProps = {
    title: 'Some base title',
    progress: false,
    showSideToolbar: false,
    showCloseIcon: false,
    showInfoBar: false
};

export default withRouter(withStyles(style)(OneColumnLayout));
