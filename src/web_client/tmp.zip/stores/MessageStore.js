import { decorate } from 'mobx';

class MessageStore {
    constructor(message) {
        this.id = message.id;
        this.value = message.value;
        this.user = message.user;
        this.time = new Date(Date.now()).toLocaleString();
    }
}

decorate(MessageStore, {

});

export default MessageStore;