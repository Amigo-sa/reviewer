import {observable, action, decorate} from 'mobx';
//import Promise from 'promise';

import {user as userApi} from '../_agents/agent';

import {getTimeZone} from '../_utils/DateUtils';

import {httpErrorHandler} from '../_utils/UserError';
import {LINK_TO_OLD_FRIEND_SETTING_NAME} from '../constants.env';
import {UsefulLinksStore, TemplatesTreeStore} from './index';

class AuthStore {
    constructor() {
        this.user = {};
        this.isAuth = false;
        this.inAlpha = null;
    }

    authenticate(username, password) {
        return userApi
            .auth(username, password)
            .then(() => this.getCurrentUser(true))
            .then(() => TemplatesTreeStore.getTemplatesTree())
            .then(action(() => (this.isAuth = true)))
            .catch(httpErrorHandler);
    }

    logout() {
        userApi
            .logout()
            .then(
                action(res => {
                    if (res.data.errno === 0) {
                        this.isAuth = false;
                        this.user = null;
                        alert('You are logged out!');
                    }
                })
            )
            .catch(httpErrorHandler);
    }

    tryAuthenticate() {
        return this.getCurrentUser()
            .then(() => {
                if (TemplatesTreeStore.templatesTree.length === 0) {
                    TemplatesTreeStore.getTemplatesTree()
                }
            })
            .then(action(() => (this.isAuth = true)))
            .catch(httpErrorHandler);
    }

    getCurrentUser(force) {
        return !force && this.user && this.isAuth
            ? Promise.resolve(this.user)
            : userApi
                .get()
                .then(
                    action(userResponse => {
                        this.user = this._parseUser(userResponse.data.object);
                        this.user['rasInfoMap'] = this._addRasInfoMapFromList(
                            userResponse.data.object.rasInfoList
                        );
                    })
                )
                .then(() => this.setTimezone())
                .then(() => this.getUserSettings())
                .catch(httpErrorHandler);
    }

    getUserSettings() {
        return userApi
            .getSetting()
            .then(
                action(
                    settings =>
                        (this.inAlpha =
                            settings.data.object.SETTING_SIDE === 'ALPHA')
                )
            );
    }

    setTimezone() {
        return userApi
            .setTimeZone(getTimeZone())
            .catch(err => console.warn(err));
    }

    getUserId(extSystem, user) {
        user = user || this.user;
        if (!user) return undefined;
        let list = user.rasInfoList;
        let kadrInfo = list.filter(a => a.extSystem === extSystem)[0];
        return kadrInfo && kadrInfo.idUser;
    }

    checkUserHaveAccessWithRole = (role) => {
        return !!this.user.kadr.roles.find(item => item === role)
    };

    getLinkToOldFriend = () => {
        return UsefulLinksStore._filterSettingsByCode(LINK_TO_OLD_FRIEND_SETTING_NAME)[0].value;
    };

    _parseUser(data) {
        return {
            ...data,
            getUserId: this.getUserId.bind(this)
        };
    }

    _addRasInfoMapFromList(list) {
        let mapList = {};

        list.map(item => {
            mapList[item.extSystem] = item;
        });

        return mapList;
    }
}

decorate(AuthStore, {
    user: observable,
    isAuth: observable,
    inAlpha: observable,
    tryAuth: action,
    getCurrentUser: action,
    logout: action
});

export default new AuthStore();
