import { observable, action, decorate } from 'mobx';

const states = {
    mainPageLayoutBaseState: {
        fullHeight: false,
    }
};


class LayoutsStore {
    constructor() {
        this.mainPageLayout = {
            fullHeight: false,
        };
    }

    setValueToLayout = (layout, valueName, value) => {
        try {
            this[layout][valueName] = value;
        } catch (error) {
            console.warn('Some error in LayoutStore.setValueToLayout', error);
        }
    };

    clearLayout = (layout) => {
        let baseState = layout + 'BaseState';

        this[layout] = { ...states[baseState] };
    }
}

decorate(LayoutsStore, {
    mainPageLayout: observable,
    setValueToLayout: action,
    clearLayout: action,
});

export default new LayoutsStore();