import { observable, action, computed, decorate } from 'mobx';
import { todos } from '../_agents/agent';

const CREATE_UP = 'CREATE_UP';
const CREATE_DOWN = 'CREATE_DOWN';
const DEADLINE_UP = 'DEADLINE_UP';
const DEADLINE_DOWN = 'DEADLINE_DOWN';

class Todos {
    constructor() {
        this.todosList = [];
        this.sortedList = [];
        this.sortBy = CREATE_UP;
    }

    get sortedBy() {
        let withDeadline = this.sortedList.filter(todo =>
            todo.hasOwnProperty('deadline')
        );
        let withoutDeadline = this.sortedList.filter(
            todo => !todo.hasOwnProperty('deadline')
        );

        switch (this.sortBy) {
            case CREATE_UP:
                return this.sortedList.sort(
                    (a, b) => Date.parse(a.openDate) - Date.parse(b.openDate)
                );
            case CREATE_DOWN:
                return this.sortedList.sort(
                    (a, b) => Date.parse(b.openDate) - Date.parse(a.openDate)
                );
            case DEADLINE_UP:
                return [
                    ...withDeadline.sort(
                        (a, b) =>
                            Date.parse(a.openDate) - Date.parse(b.openDate)
                    ),
                    ...withoutDeadline
                ];
            case DEADLINE_DOWN:
                return [
                    ...withDeadline.sort(
                        (a, b) =>
                            Date.parse(b.openDate) - Date.parse(a.openDate)
                    ),
                    ...withoutDeadline
                ];
        }
    }

    toggleSortByCreate = () => {
        this.sortBy === CREATE_UP
            ? (this.sortBy = CREATE_DOWN)
            : (this.sortBy = CREATE_UP);
    };

    toggleSortByDeadline = () => {
        this.sortBy === DEADLINE_UP
            ? (this.sortBy = DEADLINE_DOWN)
            : (this.sortBy = DEADLINE_UP);
    };

    getTodosList = count => {
        todos
            .getTodos(count)
            .then(
                action(list => {
                    console.log(list.data);
                    this.todosList = list.data.object;
                    this.sortedList = [...list.data.object];
                })
            )
            .catch(err => console.log(err));
    };

    sortShowAll = () => {
        this.sortedList = [...this.todosList];
    };

    sortIncoming = () => {
        this.sortedList = this.todosList.filter(todo => todo.my === false);
    };

    sortOutcoming = () => {
        this.sortedList = this.todosList.filter(todo => todo.my === true);
    };

    sortWithoutDeadline = () => {
        this.sortedList = this.todosList.filter(
            todo => (todo.deadline ? false : true)
        );
    };

    sortClosed = () => {
        this.sortedList = this.todosList.filter(
            todo => todo.status === 'CLOSED'
        );
    };

    sortFavorites = () => {
        this.sortedList = this.todosList.filter(todo => todo.favorite === true);
    };
}

decorate(Todos, {
    todosList: observable,
    sortedList: observable,
    sortBy: observable,
    sortedBy: computed,
    getTodosList: action,
    toggleSortByCreate: action,
    toggleSortByDeadline: action,
    sortShowAll: action,
    sortIncoming: action,
    sortOutcoming: action,
    sortWithoutDeadline: action,
    sortClosed: action,
    sortFavorites: action
});

export default new Todos();
